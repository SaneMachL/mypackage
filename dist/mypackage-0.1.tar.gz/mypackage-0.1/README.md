# mypackage
This library was created as an example of how to publush your own Python Package

# how to install
...